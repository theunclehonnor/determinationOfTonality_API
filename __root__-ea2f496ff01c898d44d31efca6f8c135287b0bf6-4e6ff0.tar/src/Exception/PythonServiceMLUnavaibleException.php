<?php

namespace App\Exception;

class PythonServiceMLUnavaibleException extends \Exception
{
    // PythonServiceMLUnavaibleException
}
